package br.com.hotelaria;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
