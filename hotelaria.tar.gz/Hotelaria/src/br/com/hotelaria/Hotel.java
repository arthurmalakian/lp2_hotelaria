package br.com.hotelaria;
import java.util.List;

import br.com.hotelaria.funcionarios.*;
import br.com.hotelaria.reservas.*;
public class Hotel {
	String nome_hotel;
	String cnpj_hotel;
	List<Camareira> camareiras;
	List<Recepcionista> recepcionistas;
	List<Reserva> reservas;
	
	
}
