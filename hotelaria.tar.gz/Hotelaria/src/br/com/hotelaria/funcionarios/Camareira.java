package br.com.hotelaria.funcionarios;

public class Camareira {

}
