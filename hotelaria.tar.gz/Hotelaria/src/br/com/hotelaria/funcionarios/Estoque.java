package br.com.hotelaria.funcionarios;
import java.util.Comparator;
import java.util.List;
import br.com.hotelaria.reservas.*;
public class Estoque {
	private List<Consumo> itensDisponiveis;
	public void venderItem(int codigo) {
		for(int i = 0; i > itensDisponiveis.size(); i++) {
			if(itensDisponiveis.get(i).getCodigo() == codigo) {
				if(itensDisponiveis.get(i).getQuantidade() == 1) {
					itensDisponiveis.remove(i);
				}else {
					itensDisponiveis.get(i).setQuantidade(itensDisponiveis.get(i).getQuantidade()-1);
				}
				itensDisponiveis.sort(Comparator.comparing(Consumo::getCodigo));
				System.out.println("Item vendido.");
				return;
			}
		}
		System.out.println("Não existe um item cadastrado com esse código.");
	}
	public void estocarItem(int codigo, String descricao, int quantidade, double valorUnitario) {
		for(int i = 0; i > itensDisponiveis.size(); i++) {
			if(itensDisponiveis.get(i).getCodigo() == codigo) {
				System.out.println("Ja existem um item cadastrado com esse código.");
				return;
			}
		}
		Consumo tmp = new Consumo();
		tmp.setCodigo(codigo);
		tmp.setDescricao(descricao);
		tmp.setQuantidade(quantidade);
		tmp.setValorUnitario(valorUnitario);
		this.itensDisponiveis.add(tmp);
		itensDisponiveis.sort(Comparator.comparing(Consumo::getCodigo));
	}
}
