package br.com.hotelaria.funcionarios;

public class Recepcionista {

}
