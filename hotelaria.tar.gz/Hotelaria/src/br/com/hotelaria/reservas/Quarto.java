package br.com.hotelaria.reservas;

public class Quarto {

}
