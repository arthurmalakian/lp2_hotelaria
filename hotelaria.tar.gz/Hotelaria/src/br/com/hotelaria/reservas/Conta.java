package br.com.hotelaria.reservas;

import java.util.List;

public class Conta {
	private List<Consumo> itensConsumidos;
	private int codigo;
	private double valor;
	private boolean pago;
	
	public List<Consumo> getItensConsumidos() {
		return itensConsumidos;
	}
	public void setItensConsumidos(List<Consumo> itensConsumidos) {
		this.itensConsumidos = itensConsumidos;
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	public boolean isPago() {
		return pago;
	}
	public void setPago(boolean pago) {
		this.pago = pago;
	}
	public void adicionarConsumo(Consumo item){
		this.getItensConsumidos().add(item);
	}
}
