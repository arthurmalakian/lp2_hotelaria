package br.com.hotelaria.reservas;

public class Hospede {
	String nome;
	String cpf;
	
}
