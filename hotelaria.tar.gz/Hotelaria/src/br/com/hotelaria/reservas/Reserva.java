package br.com.hotelaria.reservas;

public class Reserva {

}
